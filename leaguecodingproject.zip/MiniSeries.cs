﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace leagueCodingProject
{
    class MiniSeries
    {
        public int target { get; set; }
        public int wins { get; set; }
        public int losses { get; set; }
        public string progress { get; set; }
    }
}
