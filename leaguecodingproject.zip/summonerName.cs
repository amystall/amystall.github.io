﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace leagueCodingProject
{
    class summonerName
    {
        public int profileIconID { get; set; }
        public string name { get; set; }
        public string puuid { get; set; }
        public long summonerLevel { get; set; }
        public string accountId { get; set; }
        public string id { get; set; }
        public long revisionDate { get; set; }
    }
}
